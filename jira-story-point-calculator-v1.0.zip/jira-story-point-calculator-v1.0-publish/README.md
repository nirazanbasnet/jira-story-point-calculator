# JIRA Story Point Calculator

A Chrome extension that automatically calculates story points based on time tracking and complexity values in JIRA issues.

## Features

- **Automatic Operation**: Works automatically when visiting JIRA issue pages
- **Minimal Floating Panel**: Clean, modern status indicator showing extension is active
- **Real-Time Updates**: Automatically monitors field changes and updates story points
- **Smart Field Detection**: Automatically finds time tracking, complexity, and story point fields
- **Modern UI**: Sleek, minimal floating panel with glassmorphism design
- **No Popup Required**: Extension works completely in the background
- **Session Persistence**: Remembers activation state across page refreshes

## Formula

The extension uses the following formula to calculate story points:

```
Story Points = Round(Root(Time Tracking × Complexity), 2)
```

**Example:**
- Time Tracking: 2.00 hours
- Complexity: 0.20
- Calculation: Round(Root(2.00 × 0.20), 2) = Round(Root(0.40), 2) = **0.63**

## Installation

1. Clone or download this repository
2. Open Chrome and go to `chrome://extensions/`
3. Enable "Developer mode" in the top right
4. Click "Load unpacked" and select the extension folder
5. The extension icon should appear in your toolbar

## Usage

1. **Navigate to a JIRA issue page** - The extension automatically activates
2. **Floating panel appears** - Shows "Active" status with green dot
3. **Change field values** - Story points update automatically
4. **No manual intervention** - Everything works in the background

## Features

### Floating Panel
- **Minimal Design**: Clean, modern glassmorphism UI
- **Status Indicator**: Green pulsing dot shows extension is active
- **Draggable**: Can be moved around the page
- **Minimizable**: Click "−" to minimize, "×" to hide
- **Hover Effects**: Subtle animations and shadows

### Automatic Operation
- **Auto-Activation**: Works immediately on JIRA issue pages
- **Real-Time Monitoring**: Watches for field changes every 2 seconds
- **Smart Field Detection**: Automatically finds relevant fields
- **Formula Calculation**: Uses square root formula for accurate estimates

## Debugging

If the extension isn't working as expected, follow these steps:

### 1. Check Console Logs
Open the browser console (F12) and look for messages starting with "JIRA Story Point Calculator:"

### 2. Manual Calculation
In the console, run:
```javascript
triggerStoryPointCalculation()
```

### 3. Check Field Detection
The extension logs which fields it finds. Look for:
- "Found time tracking field: [selector]"
- "Found complexity field: [selector]"
- "Updated story point field with value: [number]"

### 4. Extension Control
Use these commands to control the extension:
```javascript
activateStoryPointCalculator()      // Activate the extension
deactivateStoryPointCalculator()    // Deactivate the extension
triggerStoryPointCalculation()      // Manually calculate story points
```

### 5. Common Issues

**Story points not updating automatically:**
- Check if the mutation observer is detecting field changes
- Verify that the time tracking and complexity fields are being found
- Ensure the story point field selector matches your JIRA instance

**Fields not being detected:**
- The extension uses multiple selectors to find fields
- Check the console for "Could not find [field] field" messages
- Use the debug method to see all available fields

### 6. Field Selectors

The extension looks for fields using these patterns:

**Time Tracking:**
- `[data-testid*="time-tracking"]`
- `[data-testid*="time"]`
- `.time-tracking`
- `input[name*="time"]`

**Complexity:**
- `[data-testid*="complexity"]`
- `[data-testid*="Complexity"]`
- `.complexity-field`
- `input[name*="complexity"]`

**Story Points:**
- `[data-testid="issue-field-number.ui.issue-field-story-point-estimate--container"]`
- `[data-testid*="story-point"]`
- `[data-testid*="storypoint"]`

### 7. Testing

Use the `test.html` file to test the extension locally:
1. Open `test.html` in your browser
2. Load the extension
3. Click "🚀 Activate Extension" to enable
4. Change time tracking and complexity values
5. Check if story points update automatically
6. Use "❌ Deactivate Extension" to disable

## Customization

To customize field detection for your specific JIRA instance:

1. Open the browser console on a JIRA page
2. Run: `jiraStoryPointCalculator.debugAvailableFields()`
3. Look for the field selectors in the console output
4. Update the selectors in `content.js` if needed

## Troubleshooting

**Extension not loading:**
- Check if the manifest.json is valid
- Ensure all files are in the correct directory structure
- Check Chrome extension errors in `chrome://extensions/`

**Permission errors:**
- Verify the extension has access to JIRA domains
- Check if the content script is running on the page

**Calculation errors:**
- Verify time format is supported
- Check if complexity value is in the allowed range
- Look for JavaScript errors in the console

## Support

If you continue to have issues:

1. Check the console for error messages
2. Verify your JIRA instance uses standard field names
3. Test with the provided test.html file
4. Check if JIRA has custom field configurations

## Development

The extension consists of:
- `content.js` - Main logic for field detection and calculation
- `manifest.json` - Extension configuration
- `test.html` - Local testing file
