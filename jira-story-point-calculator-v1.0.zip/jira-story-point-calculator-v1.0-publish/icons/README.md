# Icons Directory

Place your extension icons here:

- `icon16.png` (16x16 pixels)
- `icon48.png` (48x48 pixels) 
- `icon128.png` (128x128 pixels)

For now, you can use any simple PNG images or create placeholder icons.
The extension will work without icons, but they improve the user experience.
